-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: May 19, 2015 at 01:29 AM
-- Server version: 5.6.21
-- PHP Version: 5.6.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `ifs_new`
--

-- --------------------------------------------------------

--
-- Table structure for table `accounts`
--

CREATE TABLE IF NOT EXISTS `accounts` (
`id` int(11) NOT NULL,
  `number` varchar(255) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=409 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `analysis_codes`
--

CREATE TABLE IF NOT EXISTS `analysis_codes` (
`id` int(11) NOT NULL,
  `code` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `descriptions`
--

CREATE TABLE IF NOT EXISTS `descriptions` (
`id` int(11) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `type` varchar(255) NOT NULL DEFAULT 'Other'
) ENGINE=InnoDB AUTO_INCREMENT=6919 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `requests`
--

CREATE TABLE IF NOT EXISTS `requests` (
`id` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `roomid` int(11) DEFAULT NULL,
  `accountid` int(11) DEFAULT NULL,
  `codeid` int(11) DEFAULT NULL,
  `notes` longtext
) ENGINE=InnoDB AUTO_INCREMENT=14125 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `request_admin_notes`
--

CREATE TABLE IF NOT EXISTS `request_admin_notes` (
`id` int(11) NOT NULL,
  `requestid` int(11) NOT NULL,
  `note` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `request_items`
--

CREATE TABLE IF NOT EXISTS `request_items` (
`id` int(11) NOT NULL,
  `requestid` int(11) NOT NULL,
  `descriptionid` int(11) DEFAULT NULL,
  `cas` varchar(255) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `quality` varchar(1) DEFAULT NULL,
  `size` varchar(150) DEFAULT NULL,
  `vertere` int(11) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=14125 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `request_payments`
--

CREATE TABLE IF NOT EXISTS `request_payments` (
`id` int(11) NOT NULL,
  `requestid` int(11) NOT NULL,
  `type` varchar(255) NOT NULL,
  `cost` decimal(8,2) DEFAULT NULL,
  `pnnumber` varchar(255) DEFAULT NULL,
  `invoice` varchar(255) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=14125 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `request_permits`
--

CREATE TABLE IF NOT EXISTS `request_permits` (
`id` int(11) NOT NULL,
  `requestid` int(11) NOT NULL,
  `number` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `request_status`
--

CREATE TABLE IF NOT EXISTS `request_status` (
`id` int(11) NOT NULL,
  `requestid` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `date` datetime NOT NULL,
  `status` varchar(255) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=41685 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `request_suppliers`
--

CREATE TABLE IF NOT EXISTS `request_suppliers` (
`id` int(11) NOT NULL,
  `requestid` int(11) NOT NULL,
  `supplierid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `rooms`
--

CREATE TABLE IF NOT EXISTS `rooms` (
`id` int(11) NOT NULL,
  `room` varchar(255) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=426 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `sharepoint_permissions`
--

CREATE TABLE IF NOT EXISTS `sharepoint_permissions` (
`id` int(11) NOT NULL,
  `type` varchar(255) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `sharepoint_usergroups`
--

CREATE TABLE IF NOT EXISTS `sharepoint_usergroups` (
`id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `sharepoint_users`
--

CREATE TABLE IF NOT EXISTS `sharepoint_users` (
`id` int(11) NOT NULL,
  `sharepointid` int(11) DEFAULT NULL,
  `groupid` int(11) DEFAULT NULL,
  `permissionid` int(11) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=543 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `suppliers`
--

CREATE TABLE IF NOT EXISTS `suppliers` (
`id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tooltips`
--

CREATE TABLE IF NOT EXISTS `tooltips` (
`id` int(11) NOT NULL,
  `field` varchar(255) NOT NULL,
  `tooltip` longtext NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `accounts`
--
ALTER TABLE `accounts`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `number` (`number`);

--
-- Indexes for table `analysis_codes`
--
ALTER TABLE `analysis_codes`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `code` (`code`);

--
-- Indexes for table `descriptions`
--
ALTER TABLE `descriptions`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `requests`
--
ALTER TABLE `requests`
 ADD PRIMARY KEY (`id`), ADD KEY `codeid` (`codeid`), ADD KEY `accountid` (`accountid`), ADD KEY `roomid` (`roomid`), ADD KEY `userid` (`userid`);

--
-- Indexes for table `request_admin_notes`
--
ALTER TABLE `request_admin_notes`
 ADD PRIMARY KEY (`id`), ADD KEY `requestid` (`requestid`);

--
-- Indexes for table `request_items`
--
ALTER TABLE `request_items`
 ADD PRIMARY KEY (`id`), ADD KEY `requestid` (`requestid`), ADD KEY `descriptionid` (`descriptionid`);

--
-- Indexes for table `request_payments`
--
ALTER TABLE `request_payments`
 ADD PRIMARY KEY (`id`), ADD KEY `requestid` (`requestid`);

--
-- Indexes for table `request_permits`
--
ALTER TABLE `request_permits`
 ADD PRIMARY KEY (`id`), ADD KEY `requestid` (`requestid`);

--
-- Indexes for table `request_status`
--
ALTER TABLE `request_status`
 ADD PRIMARY KEY (`id`), ADD KEY `requestid` (`requestid`,`userid`), ADD KEY `userid` (`userid`);

--
-- Indexes for table `request_suppliers`
--
ALTER TABLE `request_suppliers`
 ADD PRIMARY KEY (`id`), ADD KEY `requestid` (`requestid`,`supplierid`), ADD KEY `supplierid` (`supplierid`);

--
-- Indexes for table `rooms`
--
ALTER TABLE `rooms`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sharepoint_permissions`
--
ALTER TABLE `sharepoint_permissions`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sharepoint_usergroups`
--
ALTER TABLE `sharepoint_usergroups`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `sharepoint_users`
--
ALTER TABLE `sharepoint_users`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `sharepointid` (`sharepointid`), ADD KEY `groupid` (`groupid`,`permissionid`), ADD KEY `permissionid` (`permissionid`);

--
-- Indexes for table `suppliers`
--
ALTER TABLE `suppliers`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `tooltips`
--
ALTER TABLE `tooltips`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `field` (`field`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `accounts`
--
ALTER TABLE `accounts`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=409;
--
-- AUTO_INCREMENT for table `analysis_codes`
--
ALTER TABLE `analysis_codes`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `descriptions`
--
ALTER TABLE `descriptions`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6919;
--
-- AUTO_INCREMENT for table `requests`
--
ALTER TABLE `requests`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=14125;
--
-- AUTO_INCREMENT for table `request_admin_notes`
--
ALTER TABLE `request_admin_notes`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `request_items`
--
ALTER TABLE `request_items`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=14125;
--
-- AUTO_INCREMENT for table `request_payments`
--
ALTER TABLE `request_payments`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=14125;
--
-- AUTO_INCREMENT for table `request_permits`
--
ALTER TABLE `request_permits`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `request_status`
--
ALTER TABLE `request_status`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=41685;
--
-- AUTO_INCREMENT for table `request_suppliers`
--
ALTER TABLE `request_suppliers`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `rooms`
--
ALTER TABLE `rooms`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=426;
--
-- AUTO_INCREMENT for table `sharepoint_permissions`
--
ALTER TABLE `sharepoint_permissions`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `sharepoint_usergroups`
--
ALTER TABLE `sharepoint_usergroups`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `sharepoint_users`
--
ALTER TABLE `sharepoint_users`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=543;
--
-- AUTO_INCREMENT for table `suppliers`
--
ALTER TABLE `suppliers`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `tooltips`
--
ALTER TABLE `tooltips`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=13;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `requests`
--
ALTER TABLE `requests`
ADD CONSTRAINT `requests_ibfk_1` FOREIGN KEY (`accountid`) REFERENCES `accounts` (`id`) ON UPDATE CASCADE,
ADD CONSTRAINT `requests_ibfk_2` FOREIGN KEY (`userid`) REFERENCES `sharepoint_users` (`id`) ON UPDATE CASCADE,
ADD CONSTRAINT `requests_ibfk_3` FOREIGN KEY (`roomid`) REFERENCES `rooms` (`id`) ON UPDATE CASCADE,
ADD CONSTRAINT `requests_ibfk_4` FOREIGN KEY (`codeid`) REFERENCES `analysis_codes` (`id`) ON UPDATE CASCADE;

--
-- Constraints for table `request_admin_notes`
--
ALTER TABLE `request_admin_notes`
ADD CONSTRAINT `request_admin_notes_ibfk_1` FOREIGN KEY (`requestid`) REFERENCES `requests` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `request_items`
--
ALTER TABLE `request_items`
ADD CONSTRAINT `request_items_ibfk_1` FOREIGN KEY (`requestid`) REFERENCES `requests` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
ADD CONSTRAINT `request_items_ibfk_2` FOREIGN KEY (`descriptionid`) REFERENCES `descriptions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `request_payments`
--
ALTER TABLE `request_payments`
ADD CONSTRAINT `request_payments_ibfk_1` FOREIGN KEY (`requestid`) REFERENCES `requests` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `request_permits`
--
ALTER TABLE `request_permits`
ADD CONSTRAINT `request_permits_ibfk_1` FOREIGN KEY (`requestid`) REFERENCES `requests` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `request_status`
--
ALTER TABLE `request_status`
ADD CONSTRAINT `request_status_ibfk_1` FOREIGN KEY (`requestid`) REFERENCES `requests` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
ADD CONSTRAINT `request_status_ibfk_2` FOREIGN KEY (`userid`) REFERENCES `sharepoint_users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `request_suppliers`
--
ALTER TABLE `request_suppliers`
ADD CONSTRAINT `request_suppliers_ibfk_1` FOREIGN KEY (`requestid`) REFERENCES `requests` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
ADD CONSTRAINT `request_suppliers_ibfk_2` FOREIGN KEY (`supplierid`) REFERENCES `suppliers` (`id`) ON UPDATE CASCADE;

--
-- Constraints for table `sharepoint_users`
--
ALTER TABLE `sharepoint_users`
ADD CONSTRAINT `sharepoint_users_ibfk_1` FOREIGN KEY (`groupid`) REFERENCES `sharepoint_usergroups` (`id`) ON UPDATE CASCADE,
ADD CONSTRAINT `sharepoint_users_ibfk_2` FOREIGN KEY (`permissionid`) REFERENCES `sharepoint_permissions` (`id`) ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
