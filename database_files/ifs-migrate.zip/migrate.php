<?php

$servername = "localhost";
$username = "root";
$password = "";


// Create connection
$ifs = new mysqli($servername, $username, $password, "ifs");

// Check connection
if ($ifs->connect_error) {
    die("Connection to ifs failed: " . $ifs->connect_error);
} 

$ifs_new = new mysqli($servername, $username, $password, "ifs_new");

// Check connection
if ($ifs_new->connect_error) {
    die("Connection to ifs_new failed: " . $ifs_new->connect_error);
} 




//insert accounts from n2accounts
$sql = "SELECT * FROM n2accounts";
$result = $ifs->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
		$num = $row["account_number"];
		
		$sql = "INSERT INTO accounts (number) VALUES ('$num')";

		if ($ifs_new->query($sql) === TRUE) {
			echo $sql . "<br/>";
		} else {
			echo "Error: " . $sql . "<br>" . $ifs_new->error . " <br/>";
		}	
			
		
    }
} else {
    echo "0 results" . "</br>";
}



//insert accounts from requisition
$sql = "SELECT DISTINCT account FROM requisition";
$result = $ifs->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        $account = $row["account"];
		
		$sql = "INSERT INTO accounts (number) VALUES ('$account')";

		if ($ifs_new->query($sql) === TRUE) {
		echo $sql . "<br/>";
		} else {
		echo "Error: " . $sql . "<br>" . $ifs_new->error . " <br/>";
		}	
			
		
    }
} else {
    echo "0 results" . "<br/>";
}




//insert descriptions
$sql = "SELECT DISTINCT req_type, description FROM requisition";
$result = $ifs->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        $type = $row["req_type"];
		if ($type === "C"){
			$type = "Chemical";
		}
		else{
			$type = "Other";
		}
        $description = $row["description"];
		
		$sql = "INSERT INTO descriptions (description, type) VALUES ('$description', '$type')";

		if ($ifs_new->query($sql) === TRUE) {
			echo $sql . "<br/>";
		} else {
			echo "Error: " . $sql . "<br>" . $ifs_new->error . " <br/>";
		}	
			
		
    }
} else {
    echo "0 results" . "</br>";
}







//insert rooms
$sql = "SELECT DISTINCT room FROM requisition WHERE room <> ''";
$result = $ifs->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        $room = $row["room"];
		
		$sql = "INSERT INTO rooms (room) VALUES ('$room')";

		if ($ifs_new->query($sql) === TRUE) {
			echo $sql . "<br/>";
		} else {
			echo "Error: " . $sql . "<br>" . $ifs_new->error . " <br/>";
		}	
			
		
    }
} else {
    echo "0 results" . "</br>";
}



//insert analysis codes
//dont exist in old db?



//insert suppliers
//dont exist in old db?



//insert users NOT REQUIRED ONCE SHAREPOINT INTEGRATED
$sql = "SELECT DISTINCT person_name, phone, email FROM requisitionn2";
$result = $ifs->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        $name = $row["person_name"];

		
		$phone = $row["phone"];
		
		$email = $row["email"];
		


		$sql = "INSERT INTO sharepoint_users (name, phone, email) VALUES ('$name', '$phone', '$email')";

		if ($ifs_new->query($sql) === TRUE) {
			echo $sql . "<br/>";
		} else {
			echo "Error: " . $sql . "<br>" . $ifs_new->error . " <br/>";
		}	
			
		
    }
} else {
    echo "0 results" . "</br>";
}



$sql = "SELECT DISTINCT email, phone FROM requisition";
$result = $ifs->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
		$name =  $row["email"];
        $email = $row["email"] . "@massey.ac.nz";
		$phone = $row["phone"];
		
		


		$sql = "INSERT INTO sharepoint_users (name, phone, email) VALUES ('$name', '$phone', '$email')";

		if ($ifs_new->query($sql) === TRUE) {
			echo $sql . "<br/>";
		} else {
			echo "Error: " . $sql . "<br>" . $ifs_new->error . " <br/>";
		}	
			
		
    }
} else {
    echo "0 results" . "</br>";
}















//insert requests
$sql = "SELECT * FROM requisition";
$result = $ifs->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
	
		//main request table
        $date = $row["req_date"];
		$email = $row["email"] . "@massey.ac.nz";
		$phone = $row["phone"];
		
		$sql = "SELECT id FROM sharepoint_users WHERE email = '$email' AND phone = '$phone' limit 1";

		$queryresult = $ifs_new->query($sql);
		
		if ($queryresult->num_rows > 0){
		
			$result2 = $queryresult->fetch_assoc();
			$userid = $result2["id"];
		}
		else{
			$userid = 1;
		}
		
		echo $userid;
		
		$room = $row["room"];
		$sql = "SELECT id FROM rooms WHERE room = '$room' limit 1";
		echo $sql;
		$queryresult = $ifs_new->query($sql);
		
		if ($queryresult->num_rows > 0){
		
			$result2 = $queryresult->fetch_assoc();
			$roomid = $result2["id"];
		}
		
		$account = $row["account"];
		$sql = "SELECT id FROM accounts WHERE number = '$account' limit 1";
		$queryresult = $ifs_new->query($sql);
		
		if ($queryresult->num_rows > 0){
		
			$result2 = $queryresult->fetch_assoc();
			$accountid = $result2["id"];
		}
		
		

		$notes = addslashes($row["notes"]);	
		
		
		$sql = "INSERT INTO requests (userid, roomid, accountid, notes) VALUES ('$userid', '$roomid', '$accountid', '$notes')";

		if ($ifs_new->query($sql) === TRUE) {
			echo $sql . "<br/>";
			$requestid = $ifs_new->insert_id;
		} else {
			echo "Error: " . $sql . "<br>" . $ifs_new->error . " <br/>";
			break;
		}			
		
		
		//request items table 
		
		$size = $row["size"];
		$quantity = $row["quantity"];
		$quality = $row["quality"];
		$vertere = $row["chim"];
		$cas = $row["cas"];

		$description = $row["description"];
		$sql = "SELECT id FROM descriptions WHERE description = '$description' limit 1";
		$queryresult = $ifs_new->query($sql);
		
		if ($queryresult->num_rows > 0){
		
			$result2 = $queryresult->fetch_assoc();
			$descriptionid = $result2["id"];
		}
		
		
		
		$sql = "INSERT INTO request_items (requestid, size, quantity, quality, vertere, descriptionid, cas) VALUES ('$requestid', '$size', '$quantity', '$quality', '$vertere', '$descriptionid', '$cas')";

		if ($ifs_new->query($sql) === TRUE) {
			echo $sql . "<br/>";
		} else {
			echo "Error: " . $sql . "<br>" . $ifs_new->error . " <br/>";
			break;
		}

		//no admin notes in old system, no need to migrate
		//no suppliers in old system, no need to migrate
		//no permits notes in old system, no need to migrate
		
		$date = $row["req_date"];
		if ($date !== "0000-00-00"){
			$status = "Requested";
			
			$sql = "INSERT INTO request_status (requestid, userid, date, status) VALUES ('$requestid', '$userid', '$date', '$status')";

			if ($ifs_new->query($sql) === TRUE) {
				echo $sql . "<br/>";
			} else {
				echo "Error: " . $sql . "<br>" . $ifs_new->error . " <br/>";
				break;
			}
		}	

		$date = $row["quotes_date"];
		if ($date !== "0000-00-00"){
			$status = "Quoted";
			
			$sql = "INSERT INTO request_status (requestid, userid, date, status) VALUES ('$requestid', '$userid', '$date', '$status')";

			if ($ifs_new->query($sql) === TRUE) {
				echo $sql . "<br/>";
			} else {
				echo "Error: " . $sql . "<br>" . $ifs_new->error . " <br/>";
				break;
			}
		}	


		$date = $row["order_date"];
		if ($date !== "0000-00-00"){
			$status = "Ordered";
			
			$sql = "INSERT INTO request_status (requestid, userid, date, status) VALUES ('$requestid', '$userid', '$date', '$status')";

			if ($ifs_new->query($sql) === TRUE) {
				echo $sql . "<br/>";
			} else {
				echo "Error: " . $sql . "<br>" . $ifs_new->error . " <br/>";
				break;
			}
		}	


		$date = $row["received_date"];
		if ($date !== "0000-00-00"){
			$status = "Received";
			
			$sql = "INSERT INTO request_status (requestid, userid, date, status) VALUES ('$requestid', '$userid', '$date', '$status')";

			if ($ifs_new->query($sql) === TRUE) {
				echo $sql . "<br/>";
			} else {
				echo "Error: " . $sql . "<br>" . $ifs_new->error . " <br/>";
				break;
			}
		}			
		
		
		$date = $row["supplied_date"];
		if ($date !== "0000-00-00"){
			$status = "Supplied";
			
			$sql = "INSERT INTO request_status (requestid, userid, date, status) VALUES ('$requestid', '$userid', '$date', '$status')";

			if ($ifs_new->query($sql) === TRUE) {
				echo $sql . "<br/>";
			} else {
				echo "Error: " . $sql . "<br>" . $ifs_new->error . " <br/>";
				break;
			}
		}

		$date = $row["cancelled_date"];
		if ($date !== "0000-00-00"){
			$status = "Cancelled";
			
			$sql = "INSERT INTO request_status (requestid, userid, date, status) VALUES ('$requestid', '$userid', '$date', '$status')";

			if ($ifs_new->query($sql) === TRUE) {
				echo $sql . "<br/>";
			} else {
				echo "Error: " . $sql . "<br>" . $ifs_new->error . " <br/>";
				break;
			}
		}

		$date = $row["incorrect_date"];
		if ($date !== "0000-00-00"){
			$status = "Incorrect";
			
			$sql = "INSERT INTO request_status (requestid, userid, date, status) VALUES ('$requestid', '$userid', '$date', '$status')";

			if ($ifs_new->query($sql) === TRUE) {
				echo $sql . "<br/>";
			} else {
				echo "Error: " . $sql . "<br>" . $ifs_new->error . " <br/>";
				break;
			}
		}		
		
		
		$cost = $row["cost"];
		$type = "Internal";
		
		$sql = "INSERT INTO request_payments (requestid, type, cost) VALUES ('$requestid', '$type', '$cost')";

		if ($ifs_new->query($sql) === TRUE) {
			echo $sql . "<br/>";
		} else {
			echo "Error: " . $sql . "<br>" . $ifs_new->error . " <br/>";
			break;
		}		
		
		
		

    }
} else {
    echo "0 results" . "</br>";
}		







mysqli_close($ifs);
mysqli_close($ifs_new);



/*


SET FOREIGN_KEY_CHECKS = 0; 
SET FOREIGN_KEY_CHECKS = 0; 
TRUNCATE accounts;
TRUNCATE descriptions;
TRUNCATE requests;
TRUNCATE request_admin_notes;
TRUNCATE request_items;
TRUNCATE request_payments;
TRUNCATE request_permits;
TRUNCATE request_status;
TRUNCATE request_suppliers;
TRUNCATE rooms;
TRUNCATE sharepoint_users;
SET FOREIGN_KEY_CHECKS = 1;




*/